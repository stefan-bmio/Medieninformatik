var body, main, ul, viewButton, add;
var liTemplate;

document.addEventListener("DOMContentLoaded", initialiseView);

function initialiseView() {
    body = document.getElementsByTagName("body")[0];
    main = document.getElementsByTagName("main")[0];
    ul = document.getElementsByTagName("ul")[0];
    viewButton = document.querySelector("button.view");
    add = document.getElementsByClassName("add")[0];
    liTemplate = document.getElementsByTagName("template")[0];

    while(ul.lastChild !== liTemplate){
        ul.removeChild(ul.lastChild);
    }

    function onTransitionEnd() {
        body.classList.toggle("tiles");
        body.removeEventListener("transitionend", onTransitionEnd);
        main.classList.toggle("faded");
    }

    viewButton.onclick = function () {
        main.classList.toggle("faded");
        body.addEventListener("transitionend", onTransitionEnd);
    };

    function lookupLi(el) {
        if (el.tagName.toLowerCase() === "li") {
            return el;
        } else if (el.tagName.toLowerCase() === "ul") {
            console.log("lookupLi has reached list root");
            return null;
        } else if (el.parentNode) {
            return lookupLi(el.parentNode);
        } else {
            console.error("Something has gone wrong, got: ", el);
            return null;
        }
    }

    function onListItemSelected(event) {
        var li = lookupLi(event.target);
        if (li) {
            if (event.target.classList.contains("options")) {
                if (confirm("Ok to delete  " + li.querySelector("h3.title").textContent +
                    "\nimage URL: " + li.querySelector("img").src + "?")){
                    ul.removeChild(li);
                }
            } else {
                alert("selected: " + li.querySelector("h3.title").textContent);
            }
        } else {
            alert("something went wrong");
        }
    }

    ul.onclick = onListItemSelected;

    function addNewListItem(obj) {
        var newLi = document.importNode(liTemplate.content, true);
        newLi.querySelector("img").setAttribute("src", obj.src);
        newLi.querySelector("h2.origin").textContent = obj.owner;
        newLi.querySelector("h3.title").textContent = obj.name;
        newLi.querySelector("h2.date").textContent = obj.added;
        newLi.querySelector("div.numtags h2").textContent = obj.numOfTags;
        this.ul.appendChild(newLi);
    }

    add.onclick = function (event) {
        event.stopPropagation();
        var added = new Date();
        var newItemFactor = (added.getTime() % 10) + 1;
        var newItem = {
            "name": "test" + newItemFactor,
            "owner": "placeimg.com",
            "added": added.toLocaleDateString("de-DE", {day:"2-digit", month: "2-digit", year: "numeric"}),
            "numOfTags": newItemFactor,
            "src": "https://placeimg.com/120/" + newItemFactor * 100 + "/city"
        };
        addNewListItem(newItem);
    };

    xhr("GET", "data/listitems.json", null, function (xhrobj) {
        var itemList = JSON.parse(xhrobj.responseText);
        itemList.forEach(function (obj) {
            addNewListItem(obj);
        });
    }, function () {
        alert("something went wrong");
    })
}