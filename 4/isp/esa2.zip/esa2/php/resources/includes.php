<?php
set_include_path(dirname(__FILE__)."/../");
include 'CRUD.php';
include 'validation.php';
include 'resources/resource.php';
?>
