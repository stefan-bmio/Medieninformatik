<?php
  // redirect to the login page
  header('Location: login.php');
?>
