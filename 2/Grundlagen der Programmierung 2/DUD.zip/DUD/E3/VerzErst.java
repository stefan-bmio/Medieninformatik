import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Toolklasse zum Erstellen eines Verzeichnispfades
 * 
 * @author Stefan Berger
 *
 */
public class VerzErst {
	/**
	 * Test-Mainfunktion, um die Klasse als Stand-Alone-Applikation zu testen
	 * 
	 */
	public static void main(String[] args) throws Exception {
		String path = eingeben("Bitte pfad eingeben: ");
		erstellen(path);
	}

	/**
	 * Fordert zur Eingabe eines Strings (hier: Pfad) auf und liefert diesen
	 * zur&uuml;ck
	 * 
	 * @param text
	 *            Enthaelt die Eingabeaufforderung fuer den Benutzer
	 * @return
	 */
	static String eingeben(String text) throws IOException {
		String input;

		System.out.print(text);
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		input = in.readLine();

		return input;
	}

	/**
	 * Erstellt ein Verzeichnis: Pfad+Verzeichnis entsprechen dem
	 * &uuml;bergebenen String
	 * 
	 * @param verz:
	 *            Verzeichnisname + Pfad des zu erstellenden
	 */
	static void erstellen(String verz) {
		File dir = new File(verz);
		dir.mkdirs();
	}
}
