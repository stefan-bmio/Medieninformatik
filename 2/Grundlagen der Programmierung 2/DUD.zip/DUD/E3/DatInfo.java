import java.io.File;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DatInfo {
	/**
	 * Test-Mainfunktion, um die Klasse als Stand-Alone-Applikation zu testen
	 * 
	 * @param args[0]: Pfad zur Datei.
	 */
	public static void main(String[] args) {
		final File FILE = new File(args[0]);
		aenderungAusgeben(FILE);
		dateiOderVerzeichnis(FILE);
		System.out.println(existiert(FILE) ? "existiert" : "existiert nicht");
		groesseAusgeben(FILE);
		lesenSchreiben(FILE);
		pfadAusgeben(FILE);
	}

	/**
	 * Gibt die letzte Änderung der übergebenen Datei auf der Standardausgabe aus.
	 * 
	 * @param eingabe: zu verarbeitende Datei
	 */
	static void aenderungAusgeben(File eingabe) {
		Instant instant = Instant.ofEpochMilli(eingabe.lastModified());
		LocalDateTime lastModified = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
		System.out.println(lastModified.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")));
	}
	
	/**
	 * Gibt auf der Standardausgabe aus, ob das übergebene File eine Datei oder ein Verzeichnis ist.
	 * 
	 * @param eingabe: zu verarbeitende Datei
	 */
	static void dateiOderVerzeichnis(File eingabe){
		System.out.println(eingabe.isDirectory() ? "Verzeichnis" : "regulaere Datei");
	}
	
	/**
	 * Prüft, ob die übergebene Datei existiert und gibt das Ergebnis als Boolean zurück
	 * 
	 * @param eingabe: zu überprüfende Datei
	 * @return Datei existiert?
	 */
	static boolean existiert(File eingabe){
		return eingabe.exists();
	}
	
	/**
	 * Gibt die Größe der übergebenen Datei auf der Standardausgabe aus.
	 * 
	 * @param eingabe: zu verarbeitende Datei
	 */
	static void groesseAusgeben(File eingabe){
		System.out.println(eingabe.length() + " Bytes");
	}
	
	/**
	 * Gibt die Zugriffsrechte der übergebenen Datei auf der Standardausgabe aus.
	 * 
	 * @param eingabe: zu verarbeitende Datei
	 */
	static void lesenSchreiben(File eingabe){
		String rights = "Berechtigungen: ";
		if(eingabe.canRead()){
			rights += "lesen ";
		}
		
		if(eingabe.canWrite()){
			rights += "schreiben ";
		}
		
		System.out.println(rights);
	}
	
	/**
	 * Gibt den Pfad der übergebenen Datei auf der Standardausgabe aus.
	 * 
	 * @param eingabe: zu verarbeitende Datei
	 */
	static void pfadAusgeben(File eingabe){
		System.out.println(eingabe.getAbsolutePath());
	}
}
