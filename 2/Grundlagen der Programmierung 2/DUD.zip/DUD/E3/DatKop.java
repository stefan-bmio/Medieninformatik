import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import javafx.scene.shape.Path;

/**
 * Toolklasse zum Kopieren von Dateien
 * 
 * @author Stefan Berger
 *
 */
public class DatKop {
	/**
	 * Test-Mainfunktion, um die Klasse als Stand-Alone-Applikation zu testen
	 * 
	 */
	public static void main(String[] args) {
		kopieren("datei1702_vor.html", "test");
	}

	/**
	 * Kopiert eine Datei von quelle nach ziel und gibt eine Statusmeldung auf der Standardausgabe über den Erfolg aus.
	 * 
	 */
	static void kopieren(String quelle, String ziel) {
		File inFile = new File(quelle);
		File outFile = new File(ziel);
		try {
			Files.copy(inFile.toPath(), outFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			throw new RuntimeException("Die Datei " + quelle + " konnte nicht kopiert werden.", e);
		}

		System.out.println("Die Datei " + inFile.getAbsolutePath() + " wurden erfolgreich nach "
				+ outFile.getAbsolutePath() + " kopiert.");
	}
}
