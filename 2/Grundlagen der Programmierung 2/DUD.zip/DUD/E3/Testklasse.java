import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class Testklasse {
	private final BufferedReader standardInputReader;

	public static void main(String[] args) {
		new Testklasse().mainScreen();
	}

	/**
	 * Konstruktor der Testklasse
	 */
	public Testklasse() {
		standardInputReader = new BufferedReader(new InputStreamReader(System.in));
	}

	private void mainScreen() {
		boolean isRestart;
		try {
			do {
				isRestart = true;

				System.out.println("\n#### HAUPTMENU ####\n");
				System.out.println("Verzeichnis anlegen: 1\n" + //
						"Datei kopieren: 2\n" + //
						"Dateiinformationen anzeigen: 3\n\n" + //
						"Programm beenden: 9\n");

				String input;
				do {
					System.out.print("Eingabe: ");
					input = standardInputReader.readLine();
					switch (input) {
					case "1":
						createDir();
						break;
					case "2":
						copyFile();
						break;
					case "3":
						displayFileInfo();
						break;
					case "9":
						isRestart = false;
						break;
					default:
						System.out.println("Zulaessige Eingaben sind 1, 2 oder 3");
						input = null;
					}

				} while (input == null);

			} while (isRestart);

		} catch (IOException e) {
			throw new RuntimeException("Vom Standardeingabekanal konnte nicht gelesen werden.", e);
		}
	}

	private void createDir() throws IOException {
		boolean isRepeat;
		do {
			String path = VerzErst.eingeben("Bitte Verzeichnispfad angeben: ");
			VerzErst.erstellen(path);
			System.out.print("Wollen Sie eine weitere Verzeichnisstruktur auf Ihrem Rechner anlegen? ");

			isRepeat = promptYesNo();
		} while (isRepeat);

	}

	private boolean promptYesNo() throws IOException {
		boolean response = false;

		boolean isValidInput;
		do {
			isValidInput = true;
			String repeat = standardInputReader.readLine();
			switch (repeat) {
			case "j":
			case "J":
				response = true;
				break;
			case "n":
			case "N":
				response = false;
				break;
			default:
				System.out.println("Zulaessige Eingaben sind 'j', 'J', 'n' und 'N'");
				isValidInput = false;
			}
		} while (!isValidInput);

		return response;
	}

	private void copyFile() throws IOException {
		System.out.print("Bitte Quelldatei angeben: ");
		String source = standardInputReader.readLine();

		System.out.print("Bitte Zieldatei angeben: ");
		String destination = standardInputReader.readLine();

		DatKop.kopieren(source, destination);
	}

	private void displayFileInfo() throws IOException {
		System.out.print("Bitte Dateipfad angeben: ");
		String filename = standardInputReader.readLine();
		File file = new File(filename);

		System.out.println("Wählen Sie:\n" + //
				" Dateigröße: 1\n" + //
				" Verzeichnis oder Datei: 2\n" + //
				" Letzter Tag der Änderung: 3\n" + //
				" Schreib- und Lesezugriff erlaubt ja/nein: 4\n");

		System.out.print("Eingabe: ");
		String input;
		do {
			input = standardInputReader.readLine();

			switch (input) {
			case "1":
				DatInfo.groesseAusgeben(file);
				break;
			case "2":
				DatInfo.dateiOderVerzeichnis(file);
				break;
			case "3":
				DatInfo.aenderungAusgeben(file);
				break;
			case "4":
				DatInfo.lesenSchreiben(file);
				break;
			default:
				System.out.println("Zulaessige Eingaben sind die Ziffern von 1 bis 4.");
				input = null;
			}
		} while (input == null);
	}
}
