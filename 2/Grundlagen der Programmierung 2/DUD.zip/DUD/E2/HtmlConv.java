import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/** 
 * Hauptklasse der Anwendung zum konvertieren von Text mit Sonderzeichen nach HTML
 * 
 * @author Stefan Berger
 *
 */
public class HtmlConv {
	private final static String INPUT_FILENAME = "datei1702_vor.html";
	private final static String OUTPUT_FILENAME = "datei1702_nach.html";

	// special characters and String replacements arrays in matching order
	private final static char[] SPECIAL_CHARS = new char[] { 'ä', 'Ä', 'ö', 'Ö', 'ü', 'Ü', 'ß' };
	private final static String[] STRING_REPLACEMENTS = new String[] { "auml", "Auml", "ouml", "Ouml", "uuml", "Uuml",
			"szlig" };

	public static void main(String[] args) throws Exception {
		new HtmlConv().start();
	}

	/**
	 * Konstruktor ohne Argumente (leer)
	 */
	public HtmlConv(){
		
	}
	
	private void start() {
		String fileContent = readFile();
		String html = convert(fileContent);
		writeFile(html);
	}

	private String readFile() {
		StringBuilder fileContent = new StringBuilder();

		try (BufferedReader in = new BufferedReader(new InputStreamReader((new FileInputStream(INPUT_FILENAME))))) {
			while (in.ready()) {
				fileContent.append(in.readLine()).append('\n');
			}
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Fehler: Die Datei " + INPUT_FILENAME + " wurde nicht gefunden.", e);
		} catch (IOException e) {
			throw new RuntimeException("Fehler: Die Datei " + INPUT_FILENAME + " kann nicht gelesen werden.", e);
		}

		return fileContent.toString();
	}

	private String convert(String text) {
		for (int i = 0; i < SPECIAL_CHARS.length; i++) {
			text = text.replace(String.valueOf(SPECIAL_CHARS[i]), '&' + STRING_REPLACEMENTS[i] + ';');
		}

		return text;
	}

	private void writeFile(String text) {
		try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(OUTPUT_FILENAME)))) {
			out.write(text);
		}catch(IOException e){
			throw new RuntimeException("Fehler: Die Datei " + OUTPUT_FILENAME + " konnte nicht geschrieben werden.", e);
		}
	}
}
