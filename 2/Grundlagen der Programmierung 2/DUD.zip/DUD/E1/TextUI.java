import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Textbasiertes user interface mit spezifischen Methoden fuer die
 * Eurorechner-Anwendung
 * 
 * @author Stefan Berger
 *
 */
public class TextUI {
	private BufferedReader standardInputReader;

	/**
	 * Erstellt ein TextUI-Objekt
	 */
	public TextUI() {
		this.standardInputReader = new BufferedReader(new InputStreamReader(System.in));
	}

	/**
	 * Erfragt die Ausgangswaehrung vom Benutzer. Die Auswahlmoeglichkeiten sind
	 * Euro und US-Dollar
	 * 
	 * @return die Ausgangswaehrung als {@link Currency}
	 * @throws IOException
	 *             im Fall eines Ein-/Ausgabefehlers beim Lesen von stdin
	 */
	public Currency promptCurrency() throws IOException {
		Currency currency;

		do {
			System.out.print("Eingabe der Ausgangswaehrung (E)uro oder (U)S Dollar ? : ");
			String currencyInput = standardInputReader.readLine();

			switch (currencyInput) {
			case "E":
			case "e":
				currency = Currency.EUR;
				break;
			case "U":
			case "u":
				currency = Currency.USD;
				break;
			default:
				System.out.println("Zulaessige Eingaben sind 'E', 'e', 'U', und 'u'. Bitte nochmal.");
				currency = null;
			}
		} while (currency == null);

		return currency;
	}

	/**
	 * Erfragt den Betrag in der Ausgangswaehrung vom Benutzer. Bei fehlerhafter
	 * Eingabe wird der Benutzer erneut zur Eingabe aufgefordert.
	 * 
	 * @return den Betrag in der Ausgangswaehrung als {@code double}
	 * @throws IOException
	 *             im Fall eines Ein-/Ausgabefehlers beim Lesen von stdin
	 */
	public double promptAmount() throws IOException {
		double amount = 0;

		boolean isValidInput;
		do {
			isValidInput = true;

			System.out.print("Eingabe des Betrages (Dezimaltrennzeichen Punkt, keine Tausendertrennzeichen): ");
			String amountInput = this.standardInputReader.readLine();
			try {
				amount = Double.parseDouble(amountInput);
			} catch (NumberFormatException e) {
				System.out.println("Falsche Eingabe bitte nochmal!");
				isValidInput = false;
			}
		} while (!isValidInput);

		return amount;
	}

	/**
	 * Erfragt ob der Benutzer die Eurorechner-Anwendung neu starten will. Bei
	 * fehlerhafter Eingabe wird der Benutzer erneut zur Eingabe aufgefordert.
	 * 
	 * @return {@code true} wenn der Benutzer mit Ja antwortet, ansonsten
	 *         {@code false}
	 * @throws IOException
	 *             im Fall eines Ein-/Ausgabefehlers beim Lesen vom Standardeingabestream
	 */
	public boolean promptRestart() throws IOException {
		boolean isRestart = false;

		boolean isValidInput;
		do {
			isValidInput = true;

			System.out.print("Wollen Sie noch einmal j/n? : ");
			String restartInput = this.standardInputReader.readLine();

			switch (restartInput) {
			case "J":
			case "j":
				isRestart = true;
				break;
			case "N":
			case "n":
				isRestart = false;
				break;
			default:
				System.out.println("Zulaessige Eingaben sind 'J', 'j', 'N' und 'n'");
				isValidInput = false;
			}
		} while (!isValidInput);

		return isRestart;
	}
}
