import java.io.IOException;
import java.util.Locale;

/**
 * Hauptklasse der Eurorechner-Anwendung
 * 
 * @author Stefan Berger
 *
 */
public class Eurorechner {
	private static final double RATE = 1.29535;

	private TextUI textUI;

	public static void main(String[] args) {
		Eurorechner app = new Eurorechner();
		boolean isRestart;
		do {
			isRestart = app.start();
		} while (isRestart);
	}

	/**
	 * Konstruktor der Hauptklasse
	 */
	public Eurorechner() {
		this.textUI = new TextUI();
	}

	private boolean start() {
		Currency fromCurrency;
		double fromAmount;
		try {
			fromCurrency = this.textUI.promptCurrency();
			fromAmount = this.textUI.promptAmount();
		} catch (IOException e) {
			displayIOError();
			return false;
		}

		double toAmount = 0D;
		Currency toCurrency = null;
		switch (fromCurrency) {
		case EUR:
			toAmount = fromAmount * RATE;
			toCurrency = Currency.USD;
			break;
		case USD:
			toAmount = fromAmount / RATE;
			toCurrency = Currency.EUR;
			break;
		}

		// formatted with US locale for consistency (decimal delimiter) with the
		// user input
		String output = String.format(Locale.US, "%.2f %s sind %.2f %s", fromAmount, fromCurrency, toAmount,
				toCurrency);
		System.out.println(output);

		boolean isRestart = false;
		try {
			isRestart = this.textUI.promptRestart();
		} catch (IOException e) {
			displayIOError();
			return false;
		}
		return isRestart;
	}
	
	private void displayIOError(){
		System.out.println("Vom Eingabegeraet konnte nicht gelesen werden.");
	}
}
