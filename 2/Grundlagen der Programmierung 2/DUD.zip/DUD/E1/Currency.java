
/**
 * Aufzaehlung der Waehrungen, die die Eurorechner-Anwendung umrechnen kann.
 * 
 * @author Stefan Berger
 *
 */
public enum Currency {
	EUR, 
	USD;
}
