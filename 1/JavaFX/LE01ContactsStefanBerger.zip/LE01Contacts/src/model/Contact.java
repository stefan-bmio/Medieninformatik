package model;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.image.Image;

/**
 * Represents a contact, consisting of first and last name, photo and a number
 * of email addresses.
 * 
 * @author Stefan Berger
 */
public class Contact {
	public static String[] NAMES = new String[] { "Max_Mustermann", "John_Doe", "Jean_Dupont", "Sven_Svensson",
			"Piet_Pompies" };

	private String lastName;
	private String firstName;
	private Image photo;
	private List<String> emailAddresses;

	/**
	 * Constructs a contact
	 * 
	 * @param firstName
	 * @param lastName
	 * @param photo
	 * @param emailAddresses
	 */
	public Contact(String firstName, String lastName, Image photo, List<String> emailAddresses) {
		this.lastName = lastName;
		this.firstName = firstName;
		this.photo = photo;

		this.emailAddresses = new ArrayList<>();
		emailAddresses.forEach(this::addEmailAddress);
	}

	/**
	 * Adds an email address to the email addresses of this contact. Email
	 * addresses must be at least 3 characters long and contain an '@'
	 * character. The '@' character must not be the first or the last character
	 * of the email address
	 * 
	 * @param emailAddress
	 */
	public void addEmailAddress(String emailAddress) {
		if (emailAddress.length() >= 3 && emailAddress.contains("@")
				&& !(emailAddress.startsWith("@") || emailAddress.endsWith("@"))) {
			this.emailAddresses.add(emailAddress);
		}
	}

	/**
	 * Returns the last name of this contact
	 * 
	 * @return
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Returns the first name of this contact
	 * 
	 * @return
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * return the image of this contact
	 * 
	 * @return
	 */
	public Image getPhoto() {
		return this.photo;
	}

	/**
	 * returns the email addresses of this contact
	 * 
	 * @return
	 */
	public List<String> getEmailAddresses() {
		return emailAddresses;
	}

	/**
	 * returns a String representation of this contact
	 */
	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(firstName).append(" ").append(lastName);
		if (photo != null) {
			stringBuilder.append(photo.getWidth()).append("x").append(photo.getHeight());
		}
		emailAddresses.forEach(emailAddress -> stringBuilder.append(System.lineSeparator()).append(emailAddress));
		return stringBuilder.toString();
	}

	/**
	 * Generates a contact from an array of default names.
	 * 
	 * @param index
	 *            the array index of the default
	 * @return a contact object with all attributes set to certain defaults
	 */
	public static Contact getDefaultContact(int index) {
		List<String> emailAddresses = new ArrayList<>();
		String[] firstAndLast = Contact.NAMES[index].split("_");
		String first = firstAndLast[0].toLowerCase();
		String last = firstAndLast[1].toLowerCase();
		emailAddresses.add(first + "@" + last + ".de");
		emailAddresses.add(first + "." + last + "@gmx.de");
		emailAddresses.add(first.substring(0, 1) + "." + last + "@work.com");
		emailAddresses.add(first + "@web.de");
		emailAddresses.add("mail@" + first + "-" + last + ".com");
		Image image = new Image(Contact.class.getResource("/resources/" + Contact.NAMES[index] + ".png").toString(), 85,
				85, true, true);
		return new Contact(firstAndLast[0], firstAndLast[1], image, emailAddresses);
	}
}
