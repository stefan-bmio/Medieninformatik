/**
 * Testprogramm fuer die Klasse Triangle.
 * 
 * @author Agathe Merceron. (merceron@beuth-hochschule.de)
 * @version 1.01, 24.02.2011
 */
public class TriangleTest {
    /**
     * Main-Methode zum Starten und Testen der Klasse Triangle.
     * 
     * @param args
     *            Uebergabeparameter fuer das Programm
     */
    public static void main(String[] args) {

        // ein Dreieck mit richtigen Werten nicht gleichseitig
        Triangle dreieck1 = new Triangle(1, 2.5f, 3);
        System.out.println(dreieck1.isEquilateral());
        // ein Dreieck mit richtigen Werten ist gleichseitig
        Triangle dreieck2 = new Triangle(3.2f, 3.2f, 3.2f);
        System.out.println(dreieck2.isEquilateral());
        // ein Dreieck mit falschen Werten
        Triangle dreieck3 = new Triangle(-1, 2, 3);
        // ein Dreieck mit falschen Werten
        Triangle dreieck4 = new Triangle(1, 2, 3);
        // ein Dreieck mit default Werten
        Triangle dreieck5 = new Triangle();
        // Gleichseitig pruefen
        System.out.println("Ist gleichseitig: " + dreieck5.isEquilateral());
        
        // Umfang
        Triangle dreieck6 = new Triangle(2, 3, 4);
        System.out.println("Umfang: " + dreieck6.getPerimeter());
        // ein Dreieck ist rechtwinklig
        Triangle dreieck7 = new Triangle(3, 4, 5);
        System.out.println("Ist rechtwinklig: " + dreieck7.isRightAngled());
        // ein Dreieck ist rechtwinklig
        Triangle dreieck8 = new Triangle(3, 5, 4);
        System.out.println("Ist rechtwinklig: " + dreieck8.isRightAngled());
        // ein Dreieck ist rechtwinklig
        Triangle dreieck9 = new Triangle(5, 3, 4);
        System.out.println("Ist rechtwinklig: " + dreieck9.isRightAngled());
        // ein Dreieck ist nicht rechtwinklig
        Triangle dreieck10 = new Triangle(2, 2, 3);
        System.out.println("Ist rechtwinklig: " + dreieck10.isRightAngled());
        
    }
}