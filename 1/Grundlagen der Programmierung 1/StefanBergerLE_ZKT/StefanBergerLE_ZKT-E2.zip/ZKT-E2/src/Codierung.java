import java.util.Random;

public class Codierung {
	private int zeilen;
	private int spalten;
	private char[][] matrix;

	/**
	 * Im Konstruktor werden die Anzahl der Zeilen und Spalten der Verschluesselungsmatrix an das Programm übergeben
	 */
	public Codierung(int zeilen, int spalten) {
		this.zeilen = zeilen;
		this.spalten = spalten;
		matrix = new char[zeilen][spalten];
	}

	/**
	 * Verschluesselt den als Parameter übergebenen Klartext und gibt das Ergebnis der Verschlüsselung als Rückgabewert vom Typ String zurück
	 */
	public String verschluesseleText(String text) {
		if(text.length() > zeilen * spalten){
			throw new IllegalArgumentException("Der Text ist zu lang bzw. die Schluessel zu klein");
		}
		int z = 0;
		int s = 0;
		for (char zeichen : text.toCharArray()) {
			matrix[z][s] = zeichen;
			if (++s == spalten) {
				z++;			
				s = 0;
			}
		}
		
		Random random = new Random();
		for(int i = z * spalten + s; i < zeilen * spalten; i++){
			char zufallsZeichen = (char) (32 + random.nextInt(94));
			matrix[z][s] = zufallsZeichen;
			if(++s == spalten){
				s = 0;
				z++;
			}
		}
		
		StringBuilder stringBuilder = new StringBuilder();
		for(int i = 0; i < spalten; i++){
			for (int j = 0; j < zeilen; j++){
				stringBuilder.append(matrix[j][i]);
			}
		}
		return stringBuilder.toString();
	}
	
	/**
	 * Gibt die Matrix der letzten Verschluesselung zurueck
	 */
	public char[][] getLetzteMatrix(){
		return matrix;
	}
}
