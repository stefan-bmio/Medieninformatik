import java.util.Arrays;

import de.vfh.gp1.bib.Konsole;

public class CodierungTest {
	public static void main(String[] args) {
		String text = Konsole.getInputString("Bitte zu verschluesselnden Text eingeben: ");
		int zeilen = Konsole.getInputInt("Schluessel 1: (Anzahl Zeilen): ");
		int spalten = Konsole.getInputInt("Schluessel 2: (Anzahl Spalten): ");
		Codierung codierung = new Codierung(zeilen, spalten);
		try {
			String verschluesselterText = codierung.verschluesseleText(text);
			char[][] matrix = codierung.getLetzteMatrix();
			for (int i = 0; i < matrix.length; i++) {
				System.out.println(Arrays.toString(matrix[i]));
			}
			System.out.println(verschluesselterText);
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
}
