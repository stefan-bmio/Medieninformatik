/**
 * Eine Klasse fuer verschiedene Mathematische Funktionen.
 * 
 * @author Agathe Merceron (merceron@beuth-hochschule.de)
 * @version 1.01, 02/2011
 */
public class MyMath {

    /**
     * Diese Methode berechnet und liefert die Summe von 3 Zahlen vom Typ int.
     * 
     * @param n1
     *            erste Zahl
     * @param n2
     *            zweite Zahl
     * @param n3
     *            dritte Zahl
     * @return die Summe der Zahlen
     */

    public static int summiere3Zahlen(int n1, int n2, int n3) {
        return n1 + n2 + n3;
    }
    
    /**
     * Diese Methode berechnet und liefert das Produkt von 2 Zahlen vom Typ int.
     * 
     * @param n1
     *            erste Zahl
     * @param n2
     *            zweite Zahl
     * @return das Produkt der Zahlen
     */
    public static int multipliziere2Zahlen(int n1, int n2){
    	return n1 * n2;
    }
}