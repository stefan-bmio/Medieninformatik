
public class ErgaenztesAutoTest {
	public static void main(String[] args){		
		ErgaenztesAuto auto3 = new ErgaenztesAuto("James Bond", "Aston Martin", "Rot", 1955, 275, 10, "London", "007");
		auto3.setzeNeuesZiel("Ms. Moneypenny", 30);
		System.out.println(auto3);
	}
}
