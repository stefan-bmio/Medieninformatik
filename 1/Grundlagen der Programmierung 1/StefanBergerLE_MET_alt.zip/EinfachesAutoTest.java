
public class EinfachesAutoTest {
	public static void main(String[] args){
		EinfachesAuto auto0 = new EinfachesAuto("Stefan", "Porsche", "Rot", 2016, 200, 0);
		auto0.meldung();
		System.out.println();
		
		EinfachesAuto auto1 = new EinfachesAuto("Gustav Gans", "Golf GTI", "Silberfarben", 1980, 120, 2000);
		int alter = auto1.getAlter();
		System.out.println("Das alter von auto1 ist " + alter);
		
		EinfachesAuto auto2 = new EinfachesAuto("Al Bundy", "Dodge", "Silberfarben", 1975, 75, 5000);
		auto2.meldung();
		System.out.println();
		alter = auto2.getAlter();
		System.out.println("Das alter von auto2 ist " + alter);
	}
}
