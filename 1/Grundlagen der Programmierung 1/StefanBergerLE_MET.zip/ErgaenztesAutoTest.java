public class ErgaenztesAutoTest {
	public static void main(String[] args){		
		ErgaenztesAuto auto = new ErgaenztesAuto("Max Mustermann", "VW Golf", "Rot", 2015, 110, 500, "M�nchen", "123");
		System.out.println(auto);
		System.out.println();
		
		auto.setzeNeuesZiel("Berlin", 600);
		System.out.println();
		
		System.out.println(auto);
	}
}
