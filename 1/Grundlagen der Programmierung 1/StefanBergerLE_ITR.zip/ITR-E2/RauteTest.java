
public class RauteTest {
	public static void main(String[] args){
		Raute.druckeRaute(1, "-");
		Raute.druckeRaute(6, "*");
		Raute.druckeRaute(11, "<>");
		Raute.druckeRaute(15, "-o-");
	}
}
